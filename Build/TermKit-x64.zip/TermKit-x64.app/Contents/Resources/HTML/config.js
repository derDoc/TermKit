(function ($) {

var cf = termkit.config = function () {
  
};

})(jQuery);